# Morti-Site (Brawldle)
## https://mortipins.com

## Description
Welcome to The Best Brawl Stars Website! A Brawl Stars website created by YouTuber MortipinS.
Play mini-games, read blogs, watch documentaries. 
## Credits:
MortipinS - Owner, main contents of the website, Brawldle, and the images. 
enkei64 - Mobile interface, mobile sidebar, header, and the blog. 

## How to Play - Brawldle:
### Aim of the Game:
Test your skills and guess the rank of Brawl Stars players based on their clips. 

### Points & Leaderboard (not ready, example points and leaderboard system):
Guess the correct rank: 100 points

Guess one off the correct rank: 10 points

Get a 5 win streak: x2 points

Get a 10 win streak: +500 points

Your points will show on the leaderboard if you Sign-in to your Morti-Site account.

## License
This project is licensed under the Creative Commons Attribution-NonCommercial-NoDerivatives 4.0 International License. See [LICENSE](LICENSE.md) for more details.
